create definer = root@`%` view abc as
select `db1`.`s`.`s#` AS `s#`, `db1`.`s`.`sn` AS `sn`, `db1`.`s`.`sex` AS `sex`
from `db1`.`s`
where (`db1`.`s`.`sex` = 1);

